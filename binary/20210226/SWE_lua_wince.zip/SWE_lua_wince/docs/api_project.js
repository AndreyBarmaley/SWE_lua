define({
  "name": "Lua SWE",
  "version": "0.1.1",
  "description": "Lua SWE bindings",
  "title": "Lua SWE Inteface",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2021-02-20T07:56:29.929Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});

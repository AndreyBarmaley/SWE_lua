-- fill SWE.Action

if SWE.Action == nil then
    SWE.Action = {}
    SWE.Action.FontChanged       = 333001
    SWE.Action.ObjectDirty       = 334001
    SWE.Action.ItemSelected      = 334002
    SWE.Action.ResetSelected     = 334003
    SWE.Action.ChangeValue       = 334004
end
